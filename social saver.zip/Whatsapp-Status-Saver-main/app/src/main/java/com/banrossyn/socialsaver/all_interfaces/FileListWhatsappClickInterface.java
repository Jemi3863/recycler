package com.banrossyn.socialsaver.all_interfaces;



public interface FileListWhatsappClickInterface {

    void getPosition(int position);
}

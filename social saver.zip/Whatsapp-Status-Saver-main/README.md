<p align="center">
  <h1 align="center">Whatsapp-Status-Saver</h1>
  
  <h4>Status Saver App helps you save Video, Photo from Whatsapp & Whatsapp Business.</h4>
  
- 👨‍💻 All of my projects are available at [Playstore](https://play.google.com/store/apps/dev?id=5306067645342206751)

- 📝 Articles at [Blog](https://banrossyn.blogspot.com/)

- 💬 **JAVA & KOTLIN**

- *We provide reskin service of java android code at very low cost*

- ⚡  If You want to join us than message on <a href="https://wa.me/+919694260426/">Whatsapp</a> , <a href="https://t.me/banrossyn">Telegram</a>  & <a href="banrossyn@gmail.com">Mail</a>.

> Note: `-- Apache License 2.0` you can't Publish any Source code without permission.
# 
<p align="center">
    <a href="https://www.paypal.com/paypalme/banrossyn">
      <img src="https://user-images.githubusercontent.com/97843190/184054819-e2e80e69-df46-4d38-8769-5d591673d412.png"/>
    </a>
  </p>
<p align="center">If you like my work and Source Code is really helpful for you, <strong>Show Some Love</strong></p>
   
   # What's new:
    😃 Bug Fixed.
    ⬇️ Fast Loading.
    ☄️ Improved user experience.
     
     
.
.
.

>Paid Source Code Available only in 15USD
  <a href="https://github.com/OmaPrakash/Whatsapp-Status-Saver/blob/main/StausSaver-debug.apk?raw=true">Download Demo</a>. 
<p align="center">
    <a href="https://play.google.com/store/apps/details?id=com.banrossyn.socialsaver">
      <img src="https://user-images.githubusercontent.com/118904953/204097256-27a0d979-7626-48c7-8399-2a3b6a81e5eb.png" width="1280" />
    </a>
  </p>
  

<p align="center">
    <a href="https://github.com/OmaPrakash/Whatsapp-Status-Saver/blob/main/StausSaver-debug.apk?raw=true">
      <img src="https://user-images.githubusercontent.com/118904953/203556484-c491adb2-cddc-414b-b7f7-6b55e4e2f006.png" width ="100" />
    </a>
      <a href="https://wa.me/+919694260426">
      <img src="https://user-images.githubusercontent.com/118904953/203558166-f378dbf5-0677-4537-b43b-b4f9d5f58dab.png" width ="100" />
    </a>
     <a href="banrossyn@gmail.com">
      <img src="https://user-images.githubusercontent.com/118904953/203559109-cae9680e-a035-4a3d-ab02-ecbe03997b9e.png" width ="100" />
    </a>
       <a href="https://t.me/banrossyn">
      <img src="https://user-images.githubusercontent.com/118904953/203559125-f73d94b3-c636-4366-af15-516d15bcfc71.png" width ="100" />
    </a>
  </p>
  
 # Download Now:
<p align="center">
    <a href="https://play.google.com/store/apps/details?id=com.banrossyn.socialsaver">
      <img src="https://user-images.githubusercontent.com/97843190/170808265-270075d7-678d-412b-aa04-65a7759438e2.png"  />
    </a>
  </p>
  <p align="center">
    <a href="https://play.google.com/store/apps/details?id=com.banrossyn.socialsaver">
      <img src="https://play-lh.googleusercontent.com/ShIbFEANczFIjgV9BNSDjo42kME4iz6fq8yCUm9hfca27Rhgc88coq5tBfYGF7SBy_5K=w2560-h1440" width="1280" />
    </a>
  </p>

 # About this App:
 This Story Saver & Downloader - Social Saver, can help you save photos and videos in simple steps.
Looking for an app that can easily download or repost images and videos without logging in .
This download and repost app is definitely what you want, and would like to instake it.

# Notable Features:
* Multi Save, Delete, Repost / Share,
* Easy Repost without Saving,
* Easy & Fast Saving,
* Built in Image Viewer & Video Player,
* Hundred & Thousands of Stickers for Social Sharing!
* Easy Navigation!
     

# How to Use (Status)?
1 - Check the Desired Status / Story...

2 - Open App, Click on any Status to View or Use Multi Selection...

3 - Click the Save Button...

The Status is Instantly saved to your Gallery! 😉😃
  

# Disclaimer about the usage of Social Saver app:

According to the Whatsapp user copyright procedures, you need to get permission from the owner of that Whatsapp if you want to repost them
We are not responsible for any intellectual property violation that results from an unauthorized repost of a video or photo fetched from social media using Story Saver & Downloader .
Social Saver app is not associated with Whatsapp



  
# Screenshots:

 <p align="center">
    <a>
      <img src="https://play-lh.googleusercontent.com/M-Wcpi8Rh00ytc5gAwEKOYbAFE0wn5mnZD0olarQCiezNvDM4xydYbAcQRwMXluBUPs=w2560-h1440" hight="400" width="200" />
    </a>
 <a>
      <img src="https://play-lh.googleusercontent.com/3m-UJPS42HHi1QERw8XLnf0HwBi13joHpMyFsDkjyLam3P-Ti-BwOCHl2TdRNvLcSXM=w2560-h1440" hight="400" width="200" />
    </a>
  <a>
      <img src="https://play-lh.googleusercontent.com/K6vV1RcqPeTFjeAlvYF-qXp9-zUnDdJBfY-g6mxgBckED_ovF0iIILkfIT6H8HD0Gw=w2560-h1440" hight="400" width="200" />
    </a>
 
  </p>


 <p align="center">
    <a>
      <img src="https://play-lh.googleusercontent.com/maud9oFohSpucUF2fJtHr8lPgFXPen46A4CgTY0RI0jFTI63vdU9ybc25hD-VFk7PNI=w2560-h1440" hight="400" width="200" />
    </a>
        <a>
      <img src="https://play-lh.googleusercontent.com/6baOje9u_yb2l0VgVPWQb8cVhlkTb-bEta4NMtu89kiWk3XyESD1cvbjgxv8ratuWw=w2560-h1440" hight="400" width="200" />
    </a> 
    <a>
      <img src="https://play-lh.googleusercontent.com/sIKLia8-0B6RpFO8xkc6Fs6Jj9AmoKtpz5k76SoOJs-Apd9resLkZ94EJFMjL7mnn7o=w2560-h1440" hight="400" width="200" />
    </a>
  </p>
  
# Rate the app:
Please consider rating the app if you are satisfied with the product. Thank you.

# 
<table>

<tbody>
<tr>
<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>InSaver: Reels , Story &amp; Video</li>
</ul>
  
<a href="https://play.google.com/store/apps/details?id=com.banrossyn.post.story.downloader"><img src="https://user-images.githubusercontent.com/118904953/203554664-0d81f250-6127-48be-a632-135ab42dd1a8.png"/></a></td>


<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>InStory : Post &amp; Story Saver</li>
</ul>
  
<a href="https://play.google.com/store/apps/details?id=com.banrossyn.storydownloader"><img src="https://play-lh.googleusercontent.com/DjcK-Pc16a_i6cvk2snjyHyT2twaIA3iqOIqBxX0uUwY09hvxb-0k6w02ufoY8Clxg=w2560-h1440" /></a></td>


</tr>
</tbody>

<tbody>
<tr>
<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>2048: Charm Number Puzzle Game</li>
</ul>
<a href="https://play.google.com/store/apps/details?id=com.banrossyn.merge.game2048"><img src="https://play-lh.googleusercontent.com/exSR4jzl3Leor9LhC7TpUD1DrVLplJwGhYJXSLo1wyJK4Dn_Qvf2dk4s4CNqky8QmmP_=w2560-h1440"/></a></td>


<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>Tic Tac Toe - Classic</li>
</ul>
<a href="https://play.google.com/store/apps/details?id=com.banrossyn.tic.tac.toe"><img src="https://play-lh.googleusercontent.com/B-gg84Uaw_I0sxA4a4MzU7YJt1gB5Kjs06lm_OEmUXho-mLzpNwOrElWjAfy_QLnIQ=w2560-h1440" /></a></td>


</tr>
</tbody>

<tbody>
<tr>
<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>WA &amp; WAB Status Saver</li>
</ul>
<a href="https://github.com/BanRossyn/WA-WAB-Status-Saver"><img src="https://play-lh.googleusercontent.com/ShIbFEANczFIjgV9BNSDjo42kME4iz6fq8yCUm9hfca27Rhgc88coq5tBfYGF7SBy_5K=w2560-h1440"/></a></td>


<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>2048 Classic</li>
</ul>
<a href="https://github.com/BanRossyn/2048-Classic"><img src="https://play-lh.googleusercontent.com/rtVpupsFXuIF83hHqlPCUIHa1d_D9YhinfzsuC7IOQtXOKZJSCgIfAMKuevq2p8KyRWd=w2560-h1440" /></a></td>


</tr>
</tbody>


<tbody>
<tr>

<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>Tic Tac Toe - Online</li>
</ul>
<a href="https://github.com/BanRossyn/Tic-Tac-Toe-online"><img src="https://play-lh.googleusercontent.com/qq_V4V8iP8CLCIRMj8gk8n0TJ8Bd6uPezio14PaHKcraFPvxHknCqaXtlDnzv3HpA8c=w2560-h1440"/></a></td>



<td style="width: 50%; text-align: center;">
<ul style="list-style-type: circle;">
<li>Network Speed Test</li>
</ul>
<a href="https://play.google.com/store/apps/details?id=com.banrossyn.netspeed.internetspeedmeter"><img src="https://play-lh.googleusercontent.com/AjcbpJ8RgHjrQnzxHPP0J6YGid6Nd__swSTQqppX5hA2RrOQQSE7ci6pyAuWNl3t2rk=w2560-h1440"/></a></td>


</tr>
</tbody>

</table>


    
# License: 
 ```
  Copyright 2020 Rossyn
  Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. 
  See the NOTICE file distributed with this work for additional information regarding copyright ownership. 
  The ASF licenses this file to you under the Apache License, Version 2.0 (the "License"); 
  you may not use this file except in compliance with the License. 
  You may obtain a copy of the License at 
  
  http://www.apache.org/licenses/LICENSE-2.0 
  
  Unless required by applicable law or agreed to in writing, software distributed under 
  the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
  either express or implied. See the License for the specific language governing permissions and limitations under the License."
  
  


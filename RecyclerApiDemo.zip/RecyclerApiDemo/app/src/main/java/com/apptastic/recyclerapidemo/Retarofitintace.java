package com.apptastic.recyclerapidemo;



import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Retarofitintace {
    public static Retarofitintace retarofitintace;
    Userinterface userinterface;

    Retarofitintace() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.github.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();


        userinterface = retrofit.create(Userinterface.class);
    }


    public static Retarofitintace getIntace() {
        if (retarofitintace == null) {
            retarofitintace = new Retarofitintace();
        }
        return retarofitintace;
    }
}

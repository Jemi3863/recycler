package com.apptastic.recyclerapidemo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;

import java.util.List;

public class UserAdpater extends RecyclerView.Adapter<UserAdpater.userholder> {
    MainActivity mainActivity;
    List<UserModel> alluserlist;

    public UserAdpater(MainActivity mainActivity, List<UserModel> alluserlist) {
        this.mainActivity = mainActivity;
        this.alluserlist = alluserlist;
    }

    @NonNull
    @Override
    public userholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new userholder(LayoutInflater.from(mainActivity).inflate(R.layout.item_product, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull userholder holder, int position) {
        holder.userid.setText(alluserlist.get(position).getLogin());
        holder.userid.setText(alluserlist.get(position).getUrl());

        String url = alluserlist.get(position).getAvatarUrl();

        Glide
                .with(mainActivity)
                .load(alluserlist.get(position).getAvatarUrl())
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_background)
                .into(holder.tubnail);
    }

    @Override
    public int getItemCount() {
        return alluserlist.size();
    }

    class userholder extends RecyclerView.ViewHolder {

        TextView userid,username;
        ImageView tubnail;

        public userholder(@NonNull View itemView) {
            super(itemView);
            userid = itemView.findViewById(R.id.priceTextView);
            username = itemView.findViewById(R.id.ratingiv);
            tubnail =itemView.findViewById(R.id.thumbnailImageView);
        }
    }
}

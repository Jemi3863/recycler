package com.apptastic.recyclerapidemo;

import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class ImageDetailsActivity extends AppCompatActivity {


 String imageUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_details);

        ImageView imageView = findViewById(R.id.imageView);
        imageUrl = getIntent().getStringExtra("image_url");

        Glide.with(this)
             .load(imageUrl)
             .centerCrop()
             .placeholder(R.drawable.ic_launcher_background)
             .into(imageView);

        Button downloadButton = findViewById(R.id.downloadButton);

        // Set a click listener for the download button
        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Implement the image download logic here
                downloadImage();
            }
        });
    }


    // Implement the image download logic
    private void downloadImage() {
        // You can use a library like Picasso or any other method to download the image here
        // For simplicity, we'll use a basic approach using Android's built-in DownloadManager

        // Create a download request
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(imageUrl));
        request.setTitle("Image Download");
        request.setDescription("Downloading image...");

        // Set the destination directory for the downloaded image
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "downloaded_image.jpg");

        // Get the DownloadManager service and enqueue the download request
        DownloadManager downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
        downloadManager.enqueue(request);

        // Show a toast to indicate that the download has started
        Toast.makeText(this, "Image download started.", Toast.LENGTH_SHORT).show();
    }
}